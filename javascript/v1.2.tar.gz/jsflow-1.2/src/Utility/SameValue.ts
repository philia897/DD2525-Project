// -------------------------------------------------------------
  // SameValue, 9.12

  export function SameValue(x : any,y : any) {
    return (x === y);
  } 
  