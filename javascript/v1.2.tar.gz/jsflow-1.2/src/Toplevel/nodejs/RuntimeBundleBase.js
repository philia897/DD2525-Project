// this file is intentionally js

require('core-js');
/*
require('core-js/features/symbol');
require('core-js/features/iterator');
require('core-js/features/map');
require('core-js/features/set');
require('core-js/features/array')
require('core-js/features/date')
require('core-js/features/number')
require('core-js/features/math')

require('core-js/features/string')
require('core-js/features/weak-map');
require("regenerator-runtime/runtime");
*/
uneval = require('tosource-polyfill');


